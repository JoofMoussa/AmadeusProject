from django.apps import AppConfig


class EspaceclientConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "espaceClient"
