from django.apps import AppConfig


class VolsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "vols"
